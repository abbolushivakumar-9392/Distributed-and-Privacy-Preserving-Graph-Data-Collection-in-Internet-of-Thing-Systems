import tkinter
from tkinter import *
import math
import random
from threading import Thread 
from collections import defaultdict
from tkinter import ttk
import matplotlib.pyplot as plt
import numpy as np
import time
import random
import networkx as nx
#class to apply differential privacy on dataset to secured from data leak
from pydp.algorithms.laplacian import BoundedSum
import sys
import zlib

global mobile, labels, mobile_x, mobile_y, text, canvas, source_list, root, num_nodes, tf1, nodes, dest_list, shortest_path, propose, existing, G, noise, src
option = 0
cgca = []
dmgc = []
extension = []
lines = []
output = []
global graph_data

def getDistance(iot_x,iot_y,x1,y1):
    flag = False
    for i in range(len(iot_x)):
        dist = math.sqrt((iot_x[i] - x1)**2 + (iot_y[i] - y1)**2)
        if dist < 60:
            flag = True
            break
    return flag

def generateIOT():
    global mobile, labels, mobile_x, mobile_y, num_nodes, tf1, nodes
    mobile = []
    mobile_x = []
    mobile_y = []
    labels = []
    nodes = []
    canvas.update()
    num_nodes = int(tf1.get().strip())
    for i in range(0,num_nodes):
        run = True
        while run == True:
            x = random.randint(50, 450)
            y = random.randint(50, 600)
            flag = getDistance(mobile_x,mobile_y,x,y)
            if flag == False:
                nodes.append([x, y])
                mobile_x.append(x)
                mobile_y.append(y)
                run = False
                name = canvas.create_oval(x,y,x+40,y+40, fill="red")
                lbl = canvas.create_text(x+20,y-10,fill="darkblue",font="Times 8 italic bold",text="IOT "+str(i))
                labels.append(lbl)
                mobile.append(name)    

def calculatePath():
    global source_list, dest_list, nodes, shortest_path, output, G, src
    text.delete('1.0', END)
    output.clear()
    src = int(source_list.get())
    dest = int(dest_list.get())
    G = nx.DiGraph()
    if len(lines) > 0:
        for k in range(len(lines)):
            canvas.delete(lines[k])
        lines.clear()
        canvas.update()
    for i in range(len(nodes)):
        G.add_node(str(i))        
    for i in range(len(nodes)):
        for j in range(len(nodes)):
            if i != j:
                list1 = nodes[i]
                list2 = nodes[j]
                dist = math.sqrt((list1[0] - list2[0])**2 + (list1[1] - list2[1])**2)
                if dist < 150:
                    G.add_edge(str(i), str(j), weight = dist)                    
    try:
        shortest_path = list(nx.all_shortest_paths(G, str(src), str(dest)))
        adjacency_matrix = nx.adjacency_matrix(G).toarray()
        if len(shortest_path) > 0:
            shortest_path = shortest_path[0]
        degree_source = G.degree(str(src))
        degree_dest = G.degree(str(dest))
        output.append(src)
        output.append(dest)
        output.append(list(map(int, shortest_path)))
        output.append(degree_source)
        output.append(degree_dest)
        output.append(adjacency_matrix)
        text.insert(END,"Shortest Path between Source IOT"+str(src)+" & Destination IOT"+str(dest)+"\n")
        text.insert(END,"Shortest Path : "+str(shortest_path)+"\n")
        text.insert(END,"Number of HOPS : "+str(len(shortest_path))+"\n")
        text.insert(END,"Source Connected Degree : "+str(degree_source)+"\n")
        text.insert(END,"Destination Connected Degree : "+str(degree_dest)+"\n")
        text.insert(END,"Adjacency Matrix : "+str(adjacency_matrix)+"\n")
        text.update_idletasks()
        start = 0
        while start < len(shortest_path)-1:
            end = start + 1
            src_x = mobile_x[int(shortest_path[start])]
            src_y = mobile_y[int(shortest_path[start])]
            dest_x = mobile_x[int(shortest_path[end])]
            dest_y = mobile_y[int(shortest_path[end])]
            line1 = canvas.create_line(src_x+20, src_y+20, dest_x+20, dest_y+20, fill='black', width=3)
            lines.append(line1)
            start += 1
        canvas.update()
    except Exception:
        text.insert(END,"No Shortest Path found between Source IOT"+str(src)+" & Destination IOT"+str(dest)+"\n")
        text.insert(END,"Please choose some other source and destination")

def runCGCA():
    text.delete('1.0', END)
    global output, cgca, noise
    text.insert(END,"IOT Graph after Encoding Adjacency Matrix & Differential Privacy\n\n")
    dp = BoundedSum(epsilon= 1.5, lower_bound =  0.1, upper_bound = 100, dtype ='float') 
    noise = dp.quick_result(output[2])
    data = ""
    data += "Shortest Path between Source IOT "+str(int(output[0]) + noise)+" & Destination IOT "
    data += str(int(output[1]) + noise)+"\nShortest Path : "
    for i in range(len(output[2])):
        data += str(int(output[2][i]) + noise)+" "
    data = data.strip()+"\n"
    data += "Number of Hops : "+str(len(output[2]) + noise)+"\n"
    data += "Source Connected Degree : "+str(output[3] + noise)+"\n"
    data += "Destination Connected Degree : "+str(output[4] + noise)+"\n"
    matrix = output[5]
    data += "Adjacency Matrix : "
    for k in range(len(matrix)):
        for m in range(len(matrix[i])):
            data += str(matrix[i][m] + noise)+" "
        data += "\n"    
    text.insert(END,data)
    size = sys.getsizeof(data) / 1000
    cgca.append(size)
    text.insert(END,"\nCGCA Bandwidth Size : "+str(size))

def runDMGC():
    text.delete('1.0', END)
    global output, dmgc, G, noise, src, graph_data
    data = ""
    text.insert(END,"DMGC ask each node to estimate the scale of local graph\n")
    neighbor = []
    for i in range(0, num_nodes):
        try:
            shortest_path = list(nx.all_shortest_paths(G, str(i), str(src)))
            if len(shortest_path) > 0:
                shortest_path = shortest_path[0]
                shortest_path = list(map(int, shortest_path))
                data += "Local path of node "+str(i + noise)+" = "
                for m in range(len(shortest_path)):
                    data += str(shortest_path[m] + noise)+" "
                data += "\n"
        except Exception:
            data = "No Shortest Path found between Source IOT  & Destination IOT"
            data += "Please choose some other source and destination"
    text.insert(END,"Encoded & Differential Privacy Data of DMGC\n\n")
    text.insert(END,data)
    graph_data = data
    size = sys.getsizeof(data) / 1000
    dmgc.append(size)
    text.insert(END,"\nDMGC Bandwidth Size : "+str(size))

def extensionCompression():
    text.delete('1.0', END)
    global graph_data, dmgc, extension
    compress = zlib.compress(graph_data.encode())
    text.insert(END,"Compressed Graph Data : "+str(compress)+"\n\n")
    size = sys.getsizeof(compress) / 1000
    extension.append(size)
    text.insert(END, "Graph Bandwidth Size Before Compression : "+str(dmgc[len(dmgc) - 1])+"\n")
    text.insert(END, "Graph Bandwidth Size After Compression : "+str(size)+"\n")

def graph():
    global cgca, dmgc, extension
    plt.figure(figsize=(8, 5))
    plt.grid(True)
    plt.xlabel('Local Graph')
    plt.ylabel('Bandwidth Consumption')
    plt.plot(cgca, 'ro-', color = 'green')
    plt.plot(dmgc, 'ro-', color = 'blue')
    plt.plot(extension, 'ro-', color = 'red')
    plt.legend(['CGCA', 'DMGC', 'Extension Compressed'], loc='upper left')
    plt.title('Bandwidth Consumption Graph')
    plt.show()

def Main():
    global root, tf1, text, canvas, source_list, dest_list
    root = tkinter.Tk()
    root.geometry("1300x1200")
    root.title("Distributed and Privacy Preserving Graph Data Collection in Internet of Thing Systems")
    root.resizable(True,True)
    font1 = ('times', 12, 'bold')

    canvas = Canvas(root, width = 800, height = 700)
    canvas.pack()

    l2 = Label(root, text='Num IOT:')
    l2.config(font=font1)
    l2.place(x=820,y=10)

    tf1 = Entry(root,width=10)
    tf1.config(font=font1)
    tf1.place(x=970,y=10)

    generateButton = Button(root, text="Generate IOT Network", command=generateIOT)
    generateButton.place(x=820,y=60)
    generateButton.config(font=font1)

    l1 = Label(root, text='Source IOT:')
    l1.config(font=font1)
    l1.place(x=820,y=110)

    source = []
    for i in range(0, 50):
        source.append(str(i))
    source_list = ttk.Combobox(root, values=source, postcommand=lambda: source_list.configure(values=source))
    source_list.place(x=970,y=110)
    source_list.current(0)
    source_list.config(font=font1)

    l3 = Label(root, text='Destination IOT:')
    l3.config(font=font1)
    l3.place(x=820,y=160)

    dest = []
    for i in range(0, 50):
        dest.append(str(i))
    dest_list = ttk.Combobox(root, values=dest, postcommand=lambda: dest_list.configure(values=dest))
    dest_list.place(x=970,y=160)
    dest_list.current(0)
    dest_list.config(font=font1)

    pathButton = Button(root, text="Calculate Path", command=calculatePath)
    pathButton.place(x=820,y=210)
    pathButton.config(font=font1)

    cgcaButton = Button(root, text="Run CGCA Algorithm", command=runCGCA)
    cgcaButton.place(x=960,y=210)
    cgcaButton.config(font=font1)

    dmgcButton = Button(root, text="Run DMGC Algorithm", command=runDMGC)
    dmgcButton.place(x=1140,y=210)
    dmgcButton.config(font=font1)

    graphButton = Button(root, text="Extension Graph Compression", command=extensionCompression)
    graphButton.place(x=820,y=260)
    graphButton.config(font=font1)

    graphButton = Button(root, text="Bandwidth Comparison Graph", command=graph)
    graphButton.place(x=1050,y=260)
    graphButton.config(font=font1)

    text=Text(root,height=18,width=360)
    scroll=Scrollbar(text)
    text.configure(yscrollcommand=scroll.set)
    text.place(x=800,y=310)
    
    
    root.mainloop()
   
 
if __name__== '__main__' :
    Main ()
    
